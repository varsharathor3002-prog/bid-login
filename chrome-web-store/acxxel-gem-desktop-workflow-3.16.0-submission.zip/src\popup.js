const state = document.getElementById("state");
const message = document.getElementById("message");
const jobs = document.getElementById("jobs");

chrome.runtime.sendMessage({ type: "GET_STATE" }, (result) => {
  if (!result?.ok) {
    state.textContent = "Disconnected";
    message.textContent = result?.error || "Open Acxxel and log in again.";
    return;
  }
  state.textContent = result.connected ? "Connected" : "Disconnected";
  if (!result.connected) {
    message.textContent = "Open the Acxxel app and connect the extension.";
    return;
  }
  if (!result.jobs.length) jobs.textContent = "No assigned Desktop jobs.";
  for (const job of result.jobs) {
    const row = document.createElement("div");
    row.className = "job";
    row.innerHTML = `<b>${job.model_number || job.bid_no}</b><span>${job.account_label} · ${job.status.replaceAll("_", " ")}</span>`;
    const button = document.createElement("button");
    button.textContent = job.status === "filled" ? "Filled" : "Fill current GeM tab";
    button.disabled = job.status === "filled";
    button.onclick = () => {
      button.disabled = true;
      chrome.runtime.sendMessage({ type: "START_JOB", jobId: job.id }, (response) => {
        message.textContent = response?.ok ? "Form filled. Review it in GeM." : response?.error;
        button.disabled = false;
      });
    };
    row.appendChild(button);
    jobs.appendChild(row);
  }
});
