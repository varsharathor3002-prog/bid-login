const DEFAULT_API = "http://127.0.0.1:8000/api";

async function settings() {
  return chrome.storage.local.get(["token", "apiBase"]);
}

async function api(path, options = {}) {
  const saved = await settings();
  if (!saved.token) throw new Error("Acxxel session expired. Log in to the Acxxel app again.");
  const response = await fetch(`${saved.apiBase || DEFAULT_API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${saved.token}`,
      ...(options.headers || {}),
    },
  });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) {
    await chrome.storage.local.remove("token");
    throw new Error("Acxxel session expired. Log in to the Acxxel app again.");
  }
  if (
    response.status === 403
    && /not authorized for this action/i.test(String(data.error || ""))
  ) {
    await chrome.storage.local.remove(["token", "activeJobId"]);
    throw new Error("Log in to Acxxel as Bid Analyser, then start GeM Upload again.");
  }
  if (!response.ok) throw new Error(data.error || `Acxxel API error ${response.status}`);
  return data;
}

async function startJob(jobId) {
  const job = await api(`/gem/extension/jobs/${jobId}/claim/`, {
    method: "POST",
    body: "{}",
  });
  await chrome.storage.local.set({ activeJobId: job.id });
  const existingGemTabs = await chrome.tabs.query({ url: "https://*.gem.gov.in/*" });
  const gemTab = existingGemTabs[0]
    ? await chrome.tabs.update(existingGemTabs[0].id, { active: true })
    : await chrome.tabs.create({
        url: "https://mkp.gem.gov.in/login",
        active: true,
      });
  await api(`/gem/extension/jobs/${jobId}/report/`, {
    method: "POST",
    body: JSON.stringify({
      status: "ready_for_fill",
      progress: "GeM login opened. Log in and navigate to Add New Offering manually.",
    }),
  });
  return { waitingForForm: true, tabId: gemTab.id };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "CONNECT_ACXXEL") {
      if (!message.token) throw new Error("Log in to Acxxel before connecting the extension.");
      await chrome.storage.local.set({
        token: message.token,
        apiBase: message.apiBase || DEFAULT_API,
      });
      try {
        await api("/gem/extension/jobs/");
      } catch (error) {
        await chrome.storage.local.remove(["token", "activeJobId"]);
        throw error;
      }
      return { ok: true };
    }
    if (message.type === "GET_STATE") {
      const saved = await settings();
      const jobs = saved.token ? await api("/gem/extension/jobs/") : [];
      return { ok: true, connected: Boolean(saved.token), jobs };
    }
    if (message.type === "GET_ACTIVE_JOB") {
      const saved = await chrome.storage.local.get("activeJobId");
      if (!saved.activeJobId) return { ok: true, job: null };
      const jobs = await api("/gem/extension/jobs/");
      const job = jobs.find((item) => item.id === saved.activeJobId) || null;
      if (!job || !["queued", "ready_for_fill", "filled"].includes(job.status)) {
        await chrome.storage.local.remove("activeJobId");
      }
      return { ok: true, job };
    }
    if (message.type === "CLEAR_ACTIVE_JOB") {
      await chrome.storage.local.remove("activeJobId");
      return { ok: true };
    }
    if (message.type === "START_JOB") return { ok: true, result: await startJob(message.jobId) };
    if (message.type === "GET_MRP_DOCUMENT") {
      return {
        ok: true,
        document: await api(`/gem/extension/jobs/${message.jobId}/mrp-document/`),
      };
    }
    if (message.type === "GET_BIS_DOCUMENT") {
      return {
        ok: true,
        document: await api(`/gem/extension/jobs/${message.jobId}/bis-document/`),
      };
    }
    if (message.type === "GET_PRODUCT_IMAGES") {
      return {
        ok: true,
        result: await api(`/gem/extension/jobs/${message.jobId}/product-images/`),
      };
    }
    if (message.type === "REPORT_JOB") {
      return { ok: true, job: await api(`/gem/extension/jobs/${message.jobId}/report/`, {
        method: "POST",
        body: JSON.stringify(message.report),
      }) };
    }
    return { ok: false, error: "Unknown extension message." };
  })().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});
