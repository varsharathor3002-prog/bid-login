(() => {
  const BID_PATTERN = /GEM\s*\/\s*\d{4}\s*\/\s*[A-Z]+\s*\/\s*\d+/i;
  let syncing = false;

  const text = (node) => String(node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const normalizeBidNo = (value) => String(value || "").replace(/\s+/g, "").toUpperCase();

  function runtimeMessage(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (!response?.ok) reject(new Error(response?.error || "Extension request failed."));
          else resolve(response);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  async function progress(status, message, extra = {}) {
    await runtimeMessage({ type: "GEM_BID_SYNC_PROGRESS", status, message, ...extra });
  }

  function visible(element) {
    if (!(element instanceof Element)) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  function bidCardFor(element) {
    let current = element;
    let candidate = null;
    while (current && current !== document.body) {
      const value = text(current);
      const matches = value.match(new RegExp(BID_PATTERN.source, "gi")) || [];
      if (matches.length === 1) candidate = current;
      if (matches.length > 1) break;
      current = current.parentElement;
    }
    return candidate;
  }

  function currentCards() {
    const cards = new Map();
    for (const element of document.querySelectorAll("a, span, div, td, strong")) {
      const match = text(element).match(BID_PATTERN);
      if (!match) continue;
      const bidNo = normalizeBidNo(match[0]);
      const card = bidCardFor(element);
      if (card && !cards.has(bidNo)) cards.set(bidNo, card);
    }
    return [...cards.entries()].map(([bidNo, card]) => ({ bidNo, card }));
  }

  function valueAfterLabel(raw, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const match = raw.match(new RegExp(`\\b${escaped}\\b\\s*:?\\s*(.+?)(?=\\s{2,}|Bid\/RA|Start Date|End Date|Quantity|Status|$)`, "i"));
      if (match?.[1]) return match[1].trim();
    }
    return "";
  }

  function dateFrom(value) {
    const match = String(value || "").match(/\d{4}[-/]\d{2}[-/]\d{2}(?:\s+\d{2}:\d{2}:\d{2})?|\d{2}[-/]\d{2}[-/]\d{4}(?:\s+\d{2}:\d{2}(?::\d{2})?)?/);
    if (!match) return "";
    const parsed = new Date(match[0].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$3-$2-$1"));
    return Number.isNaN(parsed.getTime()) ? match[0] : parsed.toISOString();
  }

  function productType(raw, itemName) {
    const value = `${itemName || ""} ${raw || ""}`.toLowerCase();
    if (/multifunction|printer|printing|laserjet|inkjet|mfp\b/.test(value)) return "printer";
    if (/workstation/.test(value)) return "workstation";
    if (/all[ -]?in[ -]?one|\baio\b/.test(value)) return "aio";
    if (/desktop|computer/.test(value)) return "desktop";
    return "other";
  }

  function disqualifiedControls(card) {
    const marker = [...card.querySelectorAll("a, button, [role=button], [ng-click], span, div")]
      .filter(visible)
      .find((node) => /^(technical status\s*:\s*)?disqualified$/i.test(text(node)));
    if (!marker) return [];
    const direct = marker.closest("a, button, [role=button], [ng-click]");
    const markerRect = marker.getBoundingClientRect();
    const candidates = [];
    if (direct && !BID_PATTERN.test(text(direct))) candidates.push({ node: direct, score: 120 });

    for (const icon of card.querySelectorAll("i, svg, img, [class*=eye]")) {
      if (!visible(icon)) continue;
      const iconRect = icon.getBoundingClientRect();
      const distance = Math.abs(iconRect.left - markerRect.right) + Math.abs(iconRect.top - markerRect.top);
      if (distance > 180) continue;
      const action = icon.closest("a, button, [role=button], [ng-click]") || icon;
      const attrs = `${action.getAttribute("ng-click") || ""} ${action.getAttribute("title") || ""} ${action.getAttribute("aria-label") || ""} ${action.className || ""} ${icon.className?.baseVal || icon.className || ""}`;
      let score = 140 - distance;
      if (/eye|view|reason|technical|evaluat|history/i.test(attrs)) score += 100;
      candidates.push({ node: action, score });
    }
    let parent = marker.parentElement;
    for (let depth = 0; parent && depth < 4; depth += 1, parent = parent.parentElement) {
      for (const node of parent.querySelectorAll("a, button, [role=button], [ng-click]")) {
        if (!visible(node) || BID_PATTERN.test(text(node))) continue;
        const href = node.getAttribute("href") || "";
        if (href && href !== "#" && !/^javascript:/i.test(href) && !node.hasAttribute("ng-click")) continue;
        const attrs = `${node.getAttribute("ng-click") || ""} ${node.getAttribute("title") || ""} ${node.getAttribute("aria-label") || ""} ${node.className || ""}`;
        const nodeRect = node.getBoundingClientRect();
        const distance = Math.abs(nodeRect.left - markerRect.right) + Math.abs(nodeRect.top - markerRect.top);
        let score = Math.max(0, 20 - distance / 10) - depth;
        if (/reason|technical|evaluat|history|status/i.test(attrs)) score += 50;
        if (/eye/i.test(attrs) || node.querySelector("[class*=eye], .fa-eye, .glyphicon-eye-open")) score += 70;
        if (/disqualified/i.test(text(node))) score += 25;
        candidates.push({ node, score });
      }
      if (candidates.some((item) => item.score >= 60)) break;
    }
    candidates.push({ node: marker, score: 5 });
    candidates.sort((a, b) => b.score - a.score);
    return [...new Map(candidates.map((item) => [item.node, item])).values()]
      .slice(0, 8)
      .map((item) => item.node);
  }

  function disqualifiedControl(card) {
    return disqualifiedControls(card)[0] || null;
  }

  function activateControl(control) {
    control.scrollIntoView({ block: "center", inline: "center" });
    const clickId = `bid-history-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    control.setAttribute("data-acxxel-click-id", clickId);
    document.dispatchEvent(new CustomEvent("acxxel-gem-click-control", {
      detail: { clickId },
    }));
    control.removeAttribute("data-acxxel-click-id");
  }

  function describeControl(control) {
    const attrs = [
      ["id", control.id],
      ["class", typeof control.className === "string" ? control.className : control.className?.baseVal],
      ["ng-click", control.getAttribute?.("ng-click") || control.getAttribute?.("data-ng-click")],
      ["href", control.getAttribute?.("href")],
      ["title", control.getAttribute?.("title")],
      ["aria-label", control.getAttribute?.("aria-label")],
      ["onclick", control.getAttribute?.("onclick")],
    ].filter(([, value]) => value).map(([key, value]) => `${key}=${String(value).slice(0, 100)}`);
    return `<${control.tagName?.toLowerCase() || "node"} ${attrs.join(" ")}> text=${text(control).slice(0, 80)}`;
  }

  async function waitForHistoryModal(timeout = 15000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const title = [...document.querySelectorAll("h1,h2,h3,h4,div,span")]
        .find((node) => visible(node) && /^reason for technical evaluation$/i.test(text(node)));
      if (title) {
        let modal = title.closest("[role=dialog], .modal, .modal-content, .ngdialog-content, .modal-dialog");
        if (!modal) modal = bidCardFor(title) || title.parentElement?.parentElement;
        if (modal) return modal;
      }
      const modal = [...document.querySelectorAll("[role=dialog], .modal.show, .modal.in, .ngdialog-content")]
        .find((node) => visible(node) && /reason for technical evaluation/i.test(text(node)));
      if (modal) return modal;
      await sleep(200);
    }
    return null;
  }

  function historyRows(modal) {
    const rows = [];
    const rowCandidates = modal.querySelectorAll(
      "table tr, [role=row], .table-row, .row, tbody > *, [class*=history] > *"
    );
    for (const row of rowCandidates) {
      let cellNodes = [...row.querySelectorAll(":scope > td, :scope > [role=cell], :scope > [class*=col-], :scope > .column")];
      if (cellNodes.length < 3) {
        cellNodes = [...row.querySelectorAll("td, [role=cell], [class*=col-], .column")]
          .filter((node) => visible(node));
      }
      const cells = cellNodes.map(text).filter(Boolean)
        .filter((value, index, values) => values.indexOf(value) === index);
      if (cells.length < 3) continue;
      if (!/\d{4}[-/]\d{2}[-/]\d{2}|\d{2}[-/]\d{2}[-/]\d{4}/.test(cells[0])) continue;
      rows.push({
        date_time: dateFrom(cells[0]) || cells[0],
        status: cells[1] || "",
        reason: cells[2] || "",
        comment: cells.slice(3).join(" ") || "",
      });
    }
    if (rows.length) return rows;

    const legacyValues = {};
    for (const block of modal.querySelectorAll(".well, .modal-body > div")) {
      const label = text(block.querySelector(".phead1, strong, b"));
      if (!/^(reason|comment)$/i.test(label)) continue;
      const valueNode = [...block.querySelectorAll("p, div, span")]
        .find((node) => node !== block.querySelector(".phead1") && text(node) && text(node) !== label);
      legacyValues[label.toLowerCase()] = text(valueNode);
    }
    if (legacyValues.reason || legacyValues.comment) {
      return [{
        date_time: "",
        status: "Disqualified",
        reason: legacyValues.reason || "",
        comment: legacyValues.comment || "",
      }];
    }

    const datedNodes = [...modal.querySelectorAll("td, div, span, p, li")]
      .filter((node) => visible(node))
      .filter((node) => {
        const value = text(node);
        return value.length < 1200
          && /\d{4}[-/]\d{2}[-/]\d{2}\s+\d{2}:\d{2}/.test(value)
          && /disqualified/i.test(value);
      })
      .sort((a, b) => text(a).length - text(b).length);
    for (const node of datedNodes) {
      const value = text(node);
      const dateMatch = value.match(/\d{4}[-/]\d{2}[-/]\d{2}\s+\d{2}:\d{2}(?::\d{2})?/);
      const statusMatch = value.match(/\b(disqualified|qualified|evaluated|pending)\b/i);
      if (!dateMatch || !statusMatch) continue;
      const afterStatus = value.slice((statusMatch.index || 0) + statusMatch[0].length).trim();
      rows.push({
        date_time: dateFrom(dateMatch[0]) || dateMatch[0],
        status: statusMatch[0],
        reason: afterStatus,
        comment: "",
      });
      break;
    }
    return rows;
  }

  async function waitForHistoryRows(modal, timeout = 15000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const rows = historyRows(modal);
      if (rows.length) return rows;
      await sleep(250);
    }
    return [];
  }

  function closeModal(modal) {
    const close = [...modal.querySelectorAll("button, a, [role=button], .close")]
      .find((node) => visible(node) && (/^(close|×|x)$/i.test(text(node)) || /close/i.test(node.getAttribute("aria-label") || "")));
    if (close) close.click();
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  }

  async function historyFor(card) {
    const controls = disqualifiedControls(card);
    if (!controls.length) return { rows: [], error: "history control not found" };
    let modalOpened = false;
    let modalSample = "";
    for (const control of controls) {
      activateControl(control);
      const modal = await waitForHistoryModal(3000);
      if (!modal) continue;
      modalOpened = true;
      modalSample = String(modal.innerHTML || modal.outerHTML || "")
        .replace(/\s+/g, " ")
        .slice(0, 1800);
      const rows = await waitForHistoryRows(modal);
      closeModal(modal);
      await sleep(350);
      if (rows.length) return { rows, error: "" };
    }
    return {
      rows: [],
      error: modalOpened
        ? `history popup opened but its table was empty; modal HTML: ${modalSample}`
        : `history popup did not open; controls tried: ${controls.slice(0, 4).map(describeControl).join(" | ")}`,
    };
  }

  async function extractPage() {
    const cards = currentCards();
    const results = [];
    for (const { bidNo, card } of cards) {
      const raw = text(card);
      const isDisqualified = /technical status\s*:\s*disqualified/i.test(raw) || Boolean(disqualifiedControl(card));
      const historyResult = isDisqualified ? await historyFor(card) : { rows: [], error: "" };
      const history = historyResult.rows;
      if (isDisqualified && !history.length) {
        throw new Error(`Technical Evaluation History could not be read for ${bidNo}: ${historyResult.error}.`);
      }
      const disqualifiedEvent = history.find((row) => /disqualified/i.test(row.status));
      const quantityText = valueAfterLabel(raw, ["Quantity"]);
      const itemName = valueAfterLabel(raw, ["Items", "Item", "Product Name", "Product"])
        .replace(/^s\s*:\s*/i, "");
      results.push({
        bid_no: bidNo,
        product_type: productType(raw, itemName),
        item_name: itemName,
        quantity: Number((quantityText.match(/\d+/) || [])[0]) || null,
        department: valueAfterLabel(raw, ["Department Name And Address", "Department Name & Address", "Department"]),
        start_date: dateFrom(valueAfterLabel(raw, ["Start Date", "Bid Start Date"])),
        end_date: dateFrom(valueAfterLabel(raw, ["End Date", "Bid End Date"])),
        status: valueAfterLabel(raw, ["Bid/RA Status", "Status"]),
        technical_status: isDisqualified ? "Disqualified" : valueAfterLabel(raw, ["Technical Status"]),
        is_disqualified: isDisqualified,
        disqualified_at: disqualifiedEvent?.date_time || "",
        history,
      });
    }
    return results;
  }

  function enabled(node) {
    return Boolean(node)
      && !node.disabled
      && node.getAttribute("aria-disabled") !== "true"
      && !/(^|\s)disabled(\s|$)/i.test(node.className || "");
  }

  function paginationNext() {
    const controls = [...document.querySelectorAll("button, a, [role=button], li")]
      .filter((node) => visible(node) && /^next\s*(›|»|>)?$/i.test(text(node)) && enabled(node));
    const scored = controls.map((node) => {
      let parent = node.parentElement;
      let score = 0;
      for (let depth = 0; parent && depth < 5; depth += 1, parent = parent.parentElement) {
        const parentText = text(parent);
        if (/\bprev\b/i.test(parentText)) score += 5;
        if (/\b\d+\b/.test(parentText)) score += 2;
        if (/pagination|pager/i.test(parent.className || "")) score += 8;
      }
      return { node, score };
    }).sort((a, b) => b.score - a.score);
    if (scored[0]?.node) return scored[0].node;

    const activePage = [...document.querySelectorAll(".active, [aria-current=page]")]
      .find((node) => visible(node) && /^\d+$/.test(text(node)));
    const page = Number(text(activePage));
    if (!page) return null;
    return [...document.querySelectorAll("button, a, [role=button], li")]
      .find((node) => visible(node) && enabled(node) && text(node) === String(page + 1)) || null;
  }

  async function waitForPageChange(signature, timeout = 12000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      await sleep(350);
      const nextSignature = currentCards().map((item) => item.bidNo).join("|");
      if (nextSignature && nextSignature !== signature) return true;
    }
    return false;
  }

  async function advancePage(signature) {
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      const next = paginationNext();
      if (!next) return { advanced: false, reason: "end" };
      next.scrollIntoView({ block: "center", inline: "center" });
      await sleep(250);
      next.click();
      if (await waitForPageChange(signature, 15000)) return { advanced: true };
    }
    return { advanced: false, reason: "stuck" };
  }

  async function scanAllPages() {
    if (syncing) throw new Error("A GeM bid sync is already running in this tab.");
    syncing = true;
    let page = 1;
    let saved = 0;
    const visited = new Set();
    try {
      await progress("running", "Reading GeM Technical Evaluated bids...", { page, saved });
      while (page <= 500) {
        const cards = currentCards();
        if (!cards.length) throw new Error("No GeM bid cards found. Open Bid > Bid List and apply the Technical Evaluated filters first.");
        const signature = cards.map((item) => item.bidNo).join("|");
        if (visited.has(signature)) break;
        visited.add(signature);
        const results = await extractPage();
        if (results.length) {
          const response = await runtimeMessage({ type: "SAVE_GEM_BID_RESULTS", results });
          saved += response.saved || 0;
        }
        await progress("running", `Synced page ${page}.`, { page, saved });
        const advance = await advancePage(signature);
        if (!advance.advanced) {
          if (advance.reason === "stuck") {
            throw new Error(`GeM pagination did not move after page ${page}. Keep the tab active and retry sync from this page.`);
          }
          break;
        }
        page += 1;
      }
      await progress("complete", `GeM bid sync complete. ${saved} records saved.`, { page, saved });
    } catch (error) {
      await progress("failed", error.message || "GeM bid sync failed.", { page, saved });
      throw error;
    } finally {
      syncing = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type !== "START_GEM_BID_SYNC") return undefined;
    if (syncing) {
      sendResponse({ ok: false, error: "A GeM bid sync is already running in this tab." });
      return true;
    }
    const cardCount = currentCards().length;
    sendResponse({ ok: true, started: true, cardCount });
    window.setTimeout(() => {
      scanAllPages().catch(async (error) => {
        console.error("Acxxel GeM bid sync failed:", error);
        try {
          await progress("failed", error.message || "GeM bid scanner stopped before processing the page.", { page: 0, saved: 0 });
        } catch {
          // The extension was reloaded while this page was still running.
        }
      });
    }, 0);
    return true;
  });
})();
