const state = document.getElementById("state");
const message = document.getElementById("message");
const jobs = document.getElementById("jobs");
const syncButton = document.getElementById("sync-bids");
const syncState = document.getElementById("sync-state");

function showSyncState(sync) {
  syncState.className = `sync-state ${sync?.status || ""}`;
  syncState.textContent = sync?.message || "Not synced yet.";
  syncButton.disabled = sync?.status === "running" || sync?.status === "starting";
}

syncButton.addEventListener("click", () => {
  syncButton.disabled = true;
  syncState.textContent = "Starting GeM bid sync...";
  chrome.runtime.sendMessage({ type: "START_GEM_BID_SYNC" }, (response) => {
    if (chrome.runtime.lastError || !response?.ok) {
      syncState.className = "sync-state failed";
      syncState.textContent = chrome.runtime.lastError?.message || response?.error || "Unable to start sync.";
      syncButton.disabled = false;
      return;
    }
    syncState.className = "sync-state";
    syncState.textContent = "Sync started. You may close this popup.";
  });
});

chrome.runtime.sendMessage({ type: "GET_STATE" }, (result) => {
  if (!result?.ok) {
    state.textContent = "Disconnected";
    message.textContent = result?.error || "Open Acxxel and log in again.";
    return;
  }
  state.textContent = result.connected ? "Connected" : "Disconnected";
  showSyncState(result.gemBidSync);
  if (!result.connected) {
    message.textContent = "Open the Acxxel app and connect the extension.";
    return;
  }
  if (!result.jobs.length) jobs.textContent = "No assigned Desktop jobs.";
  for (const job of result.jobs) {
    const row = document.createElement("div");
    row.className = "job";
    row.innerHTML = `<b>${job.model_number || job.bid_no}</b><span>${job.account_label} · ${job.status.replaceAll("_", " ")}</span>`;
    const button = document.createElement("button");
    button.textContent = job.status === "filled" ? "Filled" : "Fill current GeM tab";
    button.disabled = job.status === "filled";
    button.onclick = () => {
      button.disabled = true;
      chrome.runtime.sendMessage({ type: "START_JOB", jobId: job.id }, (response) => {
        message.textContent = response?.ok ? "Form filled. Review it in GeM." : response?.error;
        button.disabled = false;
      });
    };
    row.appendChild(button);
    jobs.appendChild(row);
  }
});
