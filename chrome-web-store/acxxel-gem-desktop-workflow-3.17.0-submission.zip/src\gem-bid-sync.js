(() => {
  const BID_PATTERN = /GEM\s*\/\s*\d{4}\s*\/\s*[A-Z]+\s*\/\s*\d+/i;
  let syncing = false;

  const text = (node) => String(node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const normalizeBidNo = (value) => String(value || "").replace(/\s+/g, "").toUpperCase();

  function runtimeMessage(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (!response?.ok) reject(new Error(response?.error || "Extension request failed."));
          else resolve(response);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  async function progress(status, message, extra = {}) {
    await runtimeMessage({ type: "GEM_BID_SYNC_PROGRESS", status, message, ...extra });
  }

  function visible(element) {
    if (!(element instanceof Element)) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  function bidCardFor(element) {
    let current = element;
    let candidate = null;
    while (current && current !== document.body) {
      const value = text(current);
      const matches = value.match(new RegExp(BID_PATTERN.source, "gi")) || [];
      if (matches.length === 1) candidate = current;
      if (matches.length > 1) break;
      current = current.parentElement;
    }
    return candidate;
  }

  function currentCards() {
    const cards = new Map();
    for (const element of document.querySelectorAll("a, span, div, td, strong")) {
      const match = text(element).match(BID_PATTERN);
      if (!match) continue;
      const bidNo = normalizeBidNo(match[0]);
      const card = bidCardFor(element);
      if (card && !cards.has(bidNo)) cards.set(bidNo, card);
    }
    return [...cards.entries()].map(([bidNo, card]) => ({ bidNo, card }));
  }

  function valueAfterLabel(raw, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const match = raw.match(new RegExp(`${escaped}\\s*:?\\s*(.+?)(?=\\s{2,}|Bid\/RA|Start Date|End Date|Quantity|Status|$)`, "i"));
      if (match?.[1]) return match[1].trim();
    }
    return "";
  }

  function dateFrom(value) {
    const match = String(value || "").match(/\d{4}[-/]\d{2}[-/]\d{2}(?:\s+\d{2}:\d{2}:\d{2})?|\d{2}[-/]\d{2}[-/]\d{4}(?:\s+\d{2}:\d{2}(?::\d{2})?)?/);
    if (!match) return "";
    const parsed = new Date(match[0].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$3-$2-$1"));
    return Number.isNaN(parsed.getTime()) ? match[0] : parsed.toISOString();
  }

  function disqualifiedControl(card) {
    return [...card.querySelectorAll("a, button, [role=button], span")]
      .filter(visible)
      .find((node) => /^(technical status\s*:\s*)?disqualified$/i.test(text(node))) || null;
  }

  async function waitForHistoryModal(timeout = 8000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const title = [...document.querySelectorAll("h1,h2,h3,h4,div,span")]
        .find((node) => visible(node) && /^reason for technical evaluation$/i.test(text(node)));
      if (title) {
        let modal = title.closest("[role=dialog], .modal, .modal-content, .ngdialog-content");
        if (!modal) modal = bidCardFor(title) || title.parentElement?.parentElement;
        if (modal) return modal;
      }
      await sleep(200);
    }
    return null;
  }

  function historyRows(modal) {
    const rows = [];
    for (const row of modal.querySelectorAll("table tbody tr")) {
      const cells = [...row.querySelectorAll("td")].map(text);
      if (cells.length < 3) continue;
      rows.push({
        date_time: dateFrom(cells[0]) || cells[0],
        status: cells[1] || "",
        reason: cells[2] || "",
        comment: cells.slice(3).join(" ") || "",
      });
    }
    return rows;
  }

  function closeModal(modal) {
    const close = [...modal.querySelectorAll("button, a, [role=button], .close")]
      .find((node) => visible(node) && (/^(close|×|x)$/i.test(text(node)) || /close/i.test(node.getAttribute("aria-label") || "")));
    if (close) close.click();
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  }

  async function historyFor(card) {
    const control = disqualifiedControl(card);
    if (!control) return [];
    control.click();
    const modal = await waitForHistoryModal();
    if (!modal) return [];
    const rows = historyRows(modal);
    closeModal(modal);
    await sleep(350);
    return rows;
  }

  async function extractPage() {
    const cards = currentCards();
    const results = [];
    for (const { bidNo, card } of cards) {
      const raw = text(card);
      const isDisqualified = /technical status\s*:\s*disqualified/i.test(raw) || Boolean(disqualifiedControl(card));
      const history = isDisqualified ? await historyFor(card) : [];
      const disqualifiedEvent = history.find((row) => /disqualified/i.test(row.status));
      const quantityText = valueAfterLabel(raw, ["Quantity"]);
      results.push({
        bid_no: bidNo,
        item_name: valueAfterLabel(raw, ["Item", "Product Name", "Product"]),
        quantity: Number((quantityText.match(/\d+/) || [])[0]) || null,
        department: valueAfterLabel(raw, ["Department Name And Address", "Department Name & Address", "Department"]),
        start_date: dateFrom(valueAfterLabel(raw, ["Start Date", "Bid Start Date"])),
        end_date: dateFrom(valueAfterLabel(raw, ["End Date", "Bid End Date"])),
        status: valueAfterLabel(raw, ["Bid/RA Status", "Status"]),
        technical_status: isDisqualified ? "Disqualified" : valueAfterLabel(raw, ["Technical Status"]),
        is_disqualified: isDisqualified,
        disqualified_at: disqualifiedEvent?.date_time || "",
        history,
      });
    }
    return results;
  }

  function nextButton() {
    return [...document.querySelectorAll("button, a, [role=button]")].find((node) => {
      if (!visible(node) || !/^next\s*(›|»|>)?$/i.test(text(node))) return false;
      return !node.disabled && node.getAttribute("aria-disabled") !== "true" && !/disabled/i.test(node.className || "");
    }) || null;
  }

  async function waitForPageChange(signature, timeout = 12000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      await sleep(350);
      const nextSignature = currentCards().map((item) => item.bidNo).join("|");
      if (nextSignature && nextSignature !== signature) return true;
    }
    return false;
  }

  async function scanAllPages() {
    if (syncing) throw new Error("A GeM bid sync is already running in this tab.");
    syncing = true;
    let page = 1;
    let saved = 0;
    const visited = new Set();
    try {
      await progress("running", "Reading GeM Technical Evaluated bids...", { page, saved });
      while (page <= 500) {
        const cards = currentCards();
        if (!cards.length) throw new Error("No GeM bid cards found. Open Bid > Bid List and apply the Technical Evaluated filters first.");
        const signature = cards.map((item) => item.bidNo).join("|");
        if (visited.has(signature)) break;
        visited.add(signature);
        const results = await extractPage();
        if (results.length) {
          const response = await runtimeMessage({ type: "SAVE_GEM_BID_RESULTS", results });
          saved += response.saved || 0;
        }
        await progress("running", `Synced page ${page}.`, { page, saved });
        const next = nextButton();
        if (!next) break;
        next.click();
        if (!(await waitForPageChange(signature))) break;
        page += 1;
      }
      await progress("complete", `GeM bid sync complete. ${saved} records saved.`, { page, saved });
    } catch (error) {
      await progress("failed", error.message || "GeM bid sync failed.", { page, saved });
      throw error;
    } finally {
      syncing = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type !== "START_GEM_BID_SYNC") return undefined;
    scanAllPages().catch((error) => console.error("Acxxel GeM bid sync failed:", error));
    sendResponse({ ok: true, started: true });
    return true;
  });
})();
