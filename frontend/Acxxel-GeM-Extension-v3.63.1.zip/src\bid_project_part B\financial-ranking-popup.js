(() => {
  const start = document.getElementById('financial-start');
  const stop = document.getElementById('financial-stop');
  const output = document.getElementById('financial-state');
  const startDate = document.getElementById('financial-start-date');
  const lastPage = document.getElementById('financial-last-page');
  startDate.value = localStorage.getItem('financialStartDateFrom') || startDate.value;
  lastPage.value = localStorage.getItem('financialLastPage') || lastPage.value;
  function render(state) {
    start.disabled = ['starting', 'running', 'saving', 'stopping'].includes(state?.status);
    stop.disabled = !start.disabled || state?.status === 'saving';
    output.textContent = state?.message || 'No awarded Bid/RA results scanned yet.';
    output.className = `sync-state ${state?.status || ''}`;
  }
  async function command(type, options = {}) {
    try {
      const response = await new Promise((resolve, reject) => {
        const port = chrome.runtime.connect({ name: 'financial-ranking' });
        port.onMessage.addListener((reply) => { resolve(reply); port.disconnect(); });
        port.onDisconnect.addListener(() => reject(new Error(chrome.runtime.lastError?.message || 'Financial controller disconnected.')));
        port.postMessage({ type, ...options });
      });
      if (!response?.ok) throw new Error(response?.error || 'Awarded Bid/RA scan request failed.');
      render(response.state);
    } catch (error) { output.textContent = error.message; }
  }
  start.addEventListener('click', () => {
    const page = Number(lastPage.value);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate.value)) { output.textContent = 'Choose a valid Start Date From.'; return; }
    if (!Number.isInteger(page) || page < 1 || page > 5000) { output.textContent = 'Last Page must be between 1 and 5000.'; return; }
    localStorage.setItem('financialStartDateFrom', startDate.value);
    localStorage.setItem('financialLastPage', String(page));
    start.disabled = true;
    command('FINANCIAL_START', { startDateFrom: startDate.value, lastPage: page });
  });
  stop.addEventListener('click', () => command('FINANCIAL_STOP'));
  document.getElementById('financial-copy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(output.textContent); }
    catch { output.textContent += ' Copy failed; select and copy this status manually.'; }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.financialEvalSyncState) render(changes.financialEvalSyncState.newValue);
  });
  command('FINANCIAL_STATE');
})();
