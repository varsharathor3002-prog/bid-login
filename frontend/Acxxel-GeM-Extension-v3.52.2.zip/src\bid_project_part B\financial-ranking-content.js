/* Dormant until explicitly integrated. Loading this file never starts a scan. */
(() => {
  const COMPANY_NAMES = Object.freeze(['LAPS N TABS TECHNOLOGY PRIVATE LIMITED', 'LAPS N TABS TECHNOLOGY PVT LTD']);
  const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  const header = (value) => clean(value).toLowerCase().replace(/[:*]/g, '').trim();
  const sellerKey = (value) => clean(value)
    .replace(/\s*\((?:MSE|MII)(?:\s*,\s*(?:MSE|MII))*\)\s*$/i, "")
    .trim().toUpperCase();

  function price(value) {
    const match = clean(value).match(/^(?:₹\s*|INR\s*)?(\d+|\d{1,3}(?:,\d{3})+|\d{1,2}(?:,\d{2})*,\d{3})(?:\.(\d{1,2}))?(?:\s*\(Bid Price\))?$/i);
    if (!match) return null;
    // Preserve currency precision without floating point conversion.
    return `${match[1].replace(/,/g, "")}.${(match[2] || "").padEnd(2, "0")}`;
  }

  function parseTable(headers, rows, companyNames = COMPANY_NAMES) {
    const columns = headers.map(header);
    const required = ["seller name", "offered item", "total price", "rank"];
    const indices = required.map((name) => columns.indexOf(name));
    if (indices.some((index) => index < 0)) {
      return { status: "unreadable", reason: "Financial table headers missing", sellers: [] };
    }
    if (!rows.length) return { status: "unreadable", reason: "No seller rows", sellers: [] };
    const sellers = [];
    for (const row of rows) {
      const [seller, item, amount, rankText] = indices.map((index) => clean(row[index]));
      const rank = rankText.match(/^L([1-9]\d*)$/i);
      const totalPrice = price(amount);
      if (!seller || !item || !rank || totalPrice === null || !Number.isSafeInteger(Number(rank[1]))) {
        return { status: "unreadable", reason: "Incomplete or unsupported seller row", sellers: [] };
      }
      sellers.push({ sellerName: seller, offeredItem: item, totalPrice, currency: "INR", rank: Number(rank[1]) });
    }
    const aliases = new Set(companyNames.map(sellerKey).filter(Boolean));
    const matches = sellers.filter((seller) => aliases.has(sellerKey(seller.sellerName)));
    return {
      status: "read",
      sellers,
      // Keep every published tie. Prices and row order never determine rank.
      leaders: Object.fromEntries([1, 2, 3].map((rank) => [`L${rank}`, sellers.filter((seller) => seller.rank === rank)])),
      companyMatch: !aliases.size ? "unconfigured" : matches.length === 1 ? "matched" : matches.length ? "ambiguous" : "not_found",
      companyRank: matches.length === 1 ? matches[0].rank : null,
    };
  }

  function readDocument(doc, companyNames = COMPANY_NAMES) {
    const candidates = [];
    for (const table of doc.querySelectorAll('table, [role="table"], [role="grid"]')) {
      const rows = Array.from(table.rows || table.querySelectorAll('[role="row"]'));
      const cells = (row) => Array.from(row.cells || row.querySelectorAll('[role="columnheader"], [role="cell"], [role="gridcell"]'));
      const headerIndex = rows.findIndex((row) => {
        const values = cells(row).map((cell) => header(cell.innerText || cell.textContent));
        return ["seller name", "offered item", "total price", "rank"].every((label) => values.includes(label));
      });
      if (headerIndex < 0) continue;
      candidates.push(parseTable(
        cells(rows[headerIndex]).map((cell) => cell.innerText || cell.textContent),
        rows.slice(headerIndex + 1).map((row) => cells(row).map((cell) => cell.innerText || cell.textContent)).filter((row) => row.some((value) => clean(value))),
        companyNames,
      ));
    }
    if (candidates.length !== 1) {
      return { status: "unreadable", reason: candidates.length ? "Multiple financial tables require lot selection" : "Financial table not found", sellers: [] };
    }
    return candidates[0];
  }

  function readQualification(doc, companyNames = COMPANY_NAMES) {
    const aliases = new Set(companyNames.map(sellerKey).filter(Boolean));
    const matches = [];
    const rows = [...doc.querySelectorAll('tr, [role="row"]')];
    for (const row of rows) {
      const value = clean(row.innerText || row.textContent);
      if (![...aliases].some((alias) => sellerKey(value).includes(alias))) continue;
      const statuses = [...value.matchAll(/\b(disqualified|not\s+qualified|qualified)\b/gi)].map((match) => match[1].toLowerCase());
      if (statuses.length === 1) matches.push({ status: statuses[0] === 'qualified' ? 'qualified' : 'disqualified', text: value });
    }
    // Some GeM result layouts use div grids instead of table rows. Use the
    // smallest element containing both the exact company and one status.
    if (!matches.length) {
      const candidates = [...doc.querySelectorAll('div, li')].filter((node) => {
        const value = clean(node.innerText || node.textContent);
        return [...aliases].some((alias) => sellerKey(value).includes(alias)) && /\b(?:disqualified|not\s+qualified|qualified)\b/i.test(value);
      }).filter((node) => ![...node.children].some((child) => {
        const value = clean(child.innerText || child.textContent);
        return [...aliases].some((alias) => sellerKey(value).includes(alias)) && /\b(?:disqualified|not\s+qualified|qualified)\b/i.test(value);
      }));
      for (const node of candidates) {
        const value = clean(node.innerText || node.textContent);
        const status = value.match(/\b(disqualified|not\s+qualified|qualified)\b/i)?.[1].toLowerCase();
        if (status) matches.push({ status: status === 'qualified' ? 'qualified' : 'disqualified', text: value });
      }
    }
    if (matches.length !== 1) return { status: 'unreadable', reason: matches.length ? 'Multiple Laps N Tabs qualification rows found' : 'Laps N Tabs qualification row not found' };
    return { status: 'read', companyQualification: matches[0].status };
  }

  globalThis.AcxxelFinancialRanking = Object.freeze({ parseTable, readDocument, readQualification });
})();
