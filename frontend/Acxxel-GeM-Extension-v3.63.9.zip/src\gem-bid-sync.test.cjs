const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const sourcePath = path.join(__dirname, "gem-bid-sync.js");
const source = fs.readFileSync(sourcePath, "utf8");

function cardStartDate(cardText) {
  const start = source.indexOf("function dateFrom");
  const end = source.indexOf("function productType", start);
  assert.ok(start >= 0 && end > start, "date parser helpers must remain discoverable");
  const context = {
    cardText,
    text: (node) => String(node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim(),
  };
  vm.runInNewContext(
    `${source.slice(start, end)}; parsed = opportunityCardStartDate({ innerText: cardText });`,
    context,
  );
  return context.parsed;
}

function retentionResult(valueExpression, referenceExpression) {
  const start = source.indexOf("function disqualifiedRetentionCutoff");
  const end = source.indexOf("function opportunityCardStartDate", start);
  assert.ok(start >= 0 && end > start, "retention helpers must remain discoverable");
  const context = {};
  vm.runInNewContext(
    `${source.slice(start, end)}; reference = ${referenceExpression}; result = isRecentDisqualification(${valueExpression}, reference); cutoff = disqualifiedRetentionCutoff(reference);`,
    context,
  );
  return context;
}

test("reads the current bid Start Date and time from a seller-list card", () => {
  const parsed = cardStartDate(
    "BID NO: GEM/2026/B/7867238 Participation Status: Not participated "
      + "Start Date: 15-09-2026 10:18 AM End Date: 25-09-2026 11:00 AM",
  );
  const local = new Date(parsed);
  assert.deepEqual(
    [local.getFullYear(), local.getMonth() + 1, local.getDate(), local.getHours(), local.getMinutes()],
    [2026, 9, 15, 10, 18],
  );
});

test("supports GeM's Bid/RA Start Date label", () => {
  const parsed = cardStartDate("Bid/RA Start Date: 14/09/2026 9:02 PM End Date: 17/09/2026 9:00 PM");
  const local = new Date(parsed);
  assert.deepEqual(
    [local.getFullYear(), local.getMonth() + 1, local.getDate(), local.getHours(), local.getMinutes()],
    [2026, 9, 14, 21, 2],
  );
});

test("uses the card Start Date before the PDF Dated fallback", () => {
  assert.match(source, /const bidDate = cardStartDate\s*\|\|\s*dateFrom/);
  assert.match(source, /opportunityFromText\(bidNo, response\.detailText, cardStartDate\)/);
});

test("saves each eligible opportunity immediately and preserves checked progress", () => {
  const start = source.indexOf("async function scanOpportunityPages");
  const end = source.indexOf("async function waitForBidCards", start);
  const scan = source.slice(start, end);
  assert.match(scan, /SAVE_GEM_BID_OPPORTUNITIES[\s\S]*results:\s*\[row\]/);
  assert.doesNotMatch(scan, /const eligible\s*=\s*\[\]/);
  assert.match(scan, /Opening \$\{bidNo\}[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /Selected category page \$\{page\}[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /"complete"[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /"stopped"[\s\S]*\{ page, saved, checked \}/);
});

test("only counts disqualifications inside the dashboard one-month window", () => {
  const reference = "new Date(2026, 8, 15, 13, 0, 0)";
  assert.equal(retentionResult("new Date(2026, 7, 15, 0, 0, 0).toISOString()", reference).result, true);
  assert.equal(retentionResult("new Date(2026, 7, 14, 23, 59, 59).toISOString()", reference).result, false);
  assert.equal(retentionResult("''", reference).result, false);
  assert.equal(retentionResult("new Date(2026, 8, 16, 0, 0, 0).toISOString()", reference).result, false);
});

test("one-month cutoff clamps to the previous month's last day", () => {
  const context = retentionResult("new Date(2026, 1, 28, 0, 0, 0).toISOString()", "new Date(2026, 2, 31, 13, 0, 0)");
  assert.equal(context.cutoff.getMonth(), 1);
  assert.equal(context.cutoff.getDate(), 28);
  assert.equal(context.result, true);
});

test("disqualified scan reports only dashboard-valid API saves", () => {
  const start = source.indexOf("async function scanAllPages");
  const end = source.indexOf("const OPPORTUNITY_PRODUCTS", start);
  const scan = source.slice(start, end);
  assert.match(scan, /if \(!isRecentDisqualification\(result\.disqualified_at\)\)/);
  assert.match(scan, /created \+= response\.created/);
  assert.match(scan, /updated \+= response\.updated/);
  assert.match(scan, /rejected \+= response\.rejected/);
  assert.doesNotMatch(scan, /saved.*disqualified bids from 2026/);
});
