const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const sourcePath = path.join(__dirname, "gem-bid-sync.js");
const source = fs.readFileSync(sourcePath, "utf8");

function cardStartDate(cardText) {
  const start = source.indexOf("function dateFrom");
  const end = source.indexOf("function productType", start);
  assert.ok(start >= 0 && end > start, "date parser helpers must remain discoverable");
  const context = {
    cardText,
    text: (node) => String(node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim(),
  };
  vm.runInNewContext(
    `${source.slice(start, end)}; parsed = opportunityCardStartDate({ innerText: cardText });`,
    context,
  );
  return context.parsed;
}

test("reads the current bid Start Date and time from a seller-list card", () => {
  const parsed = cardStartDate(
    "BID NO: GEM/2026/B/7867238 Participation Status: Not participated "
      + "Start Date: 15-09-2026 10:18 AM End Date: 25-09-2026 11:00 AM",
  );
  const local = new Date(parsed);
  assert.deepEqual(
    [local.getFullYear(), local.getMonth() + 1, local.getDate(), local.getHours(), local.getMinutes()],
    [2026, 9, 15, 10, 18],
  );
});

test("supports GeM's Bid/RA Start Date label", () => {
  const parsed = cardStartDate("Bid/RA Start Date: 14/09/2026 9:02 PM End Date: 17/09/2026 9:00 PM");
  const local = new Date(parsed);
  assert.deepEqual(
    [local.getFullYear(), local.getMonth() + 1, local.getDate(), local.getHours(), local.getMinutes()],
    [2026, 9, 14, 21, 2],
  );
});

test("uses the card Start Date before the PDF Dated fallback", () => {
  assert.match(source, /const bidDate = cardStartDate\s*\|\|\s*dateFrom/);
  assert.match(source, /opportunityFromText\(bidNo, response\.detailText, cardStartDate\)/);
});

test("saves each eligible opportunity immediately and preserves checked progress", () => {
  const start = source.indexOf("async function scanOpportunityPages");
  const end = source.indexOf("async function waitForBidCards", start);
  const scan = source.slice(start, end);
  assert.match(scan, /SAVE_GEM_BID_OPPORTUNITIES[\s\S]*results:\s*\[row\]/);
  assert.doesNotMatch(scan, /const eligible\s*=\s*\[\]/);
  assert.match(scan, /Opening \$\{bidNo\}[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /Selected category page \$\{page\}[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /"complete"[\s\S]*\{ page, saved, checked \}/);
  assert.match(scan, /"stopped"[\s\S]*\{ page, saved, checked \}/);
});
